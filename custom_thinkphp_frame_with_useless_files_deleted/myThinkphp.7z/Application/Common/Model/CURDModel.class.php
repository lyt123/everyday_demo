<?php
/* User:lyt123; Date:2016/10/27; QQ:1067081452 */
namespace Common\Model;

class CURDModel extends BaseModel
{

}