<?php
/*
 * author:lyt123; create_date:2016/10/27; QQ:1067081452
*/

namespace Common\Controller;

use Think\Controller;

class BaseController extends Controller
{
    /**
     * Des :filter and receive post_data
     * Auth:lyt123
     */
    protected function reqPost(array $require_data = null, array $unnecessary_data = null)
    {
        if (! IS_POST) {
            $this->ajaxReturn(ajax_error('request method error', 405));
        }
        $data = array();
        if ($require_data) {
            foreach ($require_data as $key => $value) {

                $field = is_int($key)? $value: $key;

                $_k = I('post.'.$field, null); //过滤xss攻击

                if (!$_k)
                    $this->ajaxReturn(ajax_error('lack_parameter'.$field));

                $data[$value] = $_k;
            }
        }
        if ($unnecessary_data) {
            foreach ($unnecessary_data as $key => $value) {

                $field = is_int($key)? $value: $key;

                $_k = I('post.'.$field, null);

                if(!is_null($_k)) $data[$value] = $_k;    //有post该字段则加入
            }
        }
        return $data;
    }

    /**
     * Des :filter and receive get_data
     * Auth:lyt123
     */
    protected function reqGet(array $require_data = null, array $unnecessary_data = null)
    {
        if (! IS_GET) {
            $this->ajaxReturn(ajax_error('request method error', 405));
        }
        $data = array();
        if ($require_data) {
            foreach ($require_data as $key => $value) {

                $field = is_int($key)? $value: $key;

                $_k = I('get.'.$field, null);//过滤xss攻击

                if (!$_k)
                    $this->ajaxReturn(ajax_error('lack_parameter'.$field));

                $data[$value] = $_k;
            }
        }
        if ($unnecessary_data) {
            foreach ($unnecessary_data as $key => $value) {

                $field = is_int($key)? $value: $key;

                $_k = I('get.'.$field, null);

                if(!is_null($_k))
                    $data[$value] = $_k;      //有get该字段则加入
            }
        }
        return $data;
    }
}