<?php
/* User:lyt123; Date:2016/10/27; QQ:1067081452 */
/**
 * Des : 断点测试
 * Auth: lyt123
 */
function dd($data = 'hahaa') {
    dump($data);
    exit();
}

/**
 * Des : ajax_ok
 * Auth: lyt123
 */
function ajax_ok(array $data = null, $msg = null, $status = 200)
{
    if(! $msg) $msg = 'ok';

    return array(
        'status' => $status,
        'msg'    => $msg,
        'data'   => $data
    );
}

/**
 * Des : ajax_error
 * Auth: lyt123
 */
function ajax_error($msg = null, $status = 422, $detail = null)
{
    if(! $msg) $msg = 'error';

    return array(
        'status' => $status,
        'msg'    => $msg,
        'detail' => $detail
    );
}