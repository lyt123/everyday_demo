<?php
/* User=lyt123; Date=2016/10/29; QQ=1067081452 */
namespace Admin\Controller;

use Common\Controller\BaseController;

class CourseController extends BaseController
{
    public function courseToAdd()
    {
        $data["name"] = "旅游管理";//课程名称
        $data["code"] = "AY150303";//班级名称
        $data["type"] = "0";//0-A类班，1-B类班，2-村官班
        //班级已选情况
        $data["select"]["title"] = ["课程名称", "总学时", "星期一晚上", "星期二晚上", "星期三晚上", "星期四晚上", "星期五晚上", "星期六晚上", "星期日上午", "星期日下午", "星期日晚上"];
        $data["select"]["content"] = [
            ["比较文学专题", "24", "", "", "", "", "", "", "", "", "1-2,4,7-9周,四节(马兰芳教学楼301"],
            ["文学理论专题", "24", "", "", "", "", "", "", "", "10-15周, 四节(马兰芳教学楼301)", ""]
        ];
        $data["class_combine"] = "BY150302、303";//合班情况
        $data["hour_sum"] = 20;//总时长
        $data["student_num"] = 32;//总人数
        $data["require"] = "1-8周周日上午";//排课要求
        $data["no_assign"] = ["第5-19周星期二第1、2节", "第5-13周星期四第3、4节", "第1-16周星期三第3、4节"];//不能排时间
        $this->ajaxReturn(ajax_ok($data));
    }

    public function getTeacherNameFromExeclAndExtractTeacherClassFromShoolWebsiteHtmlThenInfillExcel()
    {
        include_once(ROOT_PATH.'Public/plugins/excel/PHPExcel.php');
        $objPHPExcel =  \PHPExcel_IOFactory::load(ROOT_PATH.'Public/excel.xlsx');
        $teacher_no_assign = self::getTeacherNameFromExeclAndExtractTeacherClassFromShoolWebsiteHtml($objPHPExcel);

        foreach($teacher_no_assign as $key => $item) {
            $string = implode('\n', $item);
            $objPHPExcel->setActiveSheetIndex(0)
                ->setCellValue( 'K'.($key+2), $string);
            $objPHPExcel->getActiveSheet()->getStyle('K'.($key+2))->getAlignment()->setWrapText(true);
        }

        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="01simple.xls"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
        $objWriter->save(ROOT_PATH.'Public/generate.xls');
    }

    public function getTeacherNameFromExeclAndExtractTeacherClassFromShoolWebsiteHtml($objPHPExcel)
    {
        $data = $objPHPExcel->getActiveSheet()->toArray(null, true, true, false);
        unset($data[0]);
        $teacher_no_assign = array();//教师不能上课的时间段
        foreach($data as $item) {
            $teacher_no_assign[] = self::extractTeacherClassFromShoolWebsiteHtml($item[9]);
        }
        return $teacher_no_assign;
    }

    public function extractTeacherClassFromShoolWebsiteHtml($teacher)
    {
        $html = self::getTeacherClassFromSchoolWebsite($teacher);
        $html = str_replace('<head>', '<head><meta http-equiv="Content-Type" content="text/html;charset=utf-8">', $html);
//        iconv('gbk', 'utf-8', $html);
//        dd(mb_detect_encoding($html, array("ASCII",'UTF-8',"GB2312","GBK",'BIG5')));
        $doc = new \DOMDocument();
        $doc->loadHTML($html);
        $i = 0;
        $data = array();
        while(
            $content = $doc->getElementById('ctl00_ContentPlaceHolder1_ListViewXKH_ctrl'.$i.'_ctimeLabel')
        ) {
            if($content->textContent)
                $data[] = $content->textContent;
            $i++;
        }
        return $data;
    }
    
    public function getTeacherClassFromSchoolWebsite($teacher)
    {
        $array = array(
            "__VIEWSTATE" => '/wEPDwUJODA1MTU4MTc3D2QWAmYPZBYCAgMPZBYGAgEPDxYCHgRUZXh0BSEyMDE2LTIwMTflrablubQ8YnIgLz7nrKzkuIDlrabmnJ9kZAIDDzwrAAkCAA8WCB4NTmV2ZXJFeHBhbmRlZGQeC18hRGF0YUJvdW5kZx4MU2VsZWN0ZWROb2RlBRFjdGwwMF9UcmVlVmlldzF0MB4JTGFzdEluZGV4AghkCBQrAAIFAzA6MBQrAAIWDB8ABQzlvIDor77mn6Xor6IeC05hdmlnYXRlVXJsBRIva2tjeC9kZWZhdWx0LmFzcHgeCERhdGFQYXRoBRIva2tjeC9kZWZhdWx0LmFzcHgeCURhdGFCb3VuZGceCFNlbGVjdGVkZx4IRXhwYW5kZWRnFCsACAUbMDowLDA6MSwwOjIsMDozLDA6NCwwOjUsMDo2FCsAAhYKHwAFDOePree6p+ivvuihqB8FBQ8va2tjeC9iamtiLmFzcHgfBgUPL2trY3gvYmprYi5hc3B4HwdnHwlnZBQrAAIWCh8ABQzpmaLns7vlvIDor74fBQUPL2trY3gveXhray5hc3B4HwYFDy9ra2N4L3l4a2suYXNweB8HZx8JZ2QUKwACFgofAAUJ5YWs6YCJ6K++HwUFDi9ra2N4L2d4ay5hc3B4HwYFDi9ra2N4L2d4ay5hc3B4HwdnHwlnZBQrAAIWCh8ABQnpgJror4bor74fBQUOL2trY3gvdHNrLmFzcHgfBgUOL2trY3gvdHNrLmFzcHgfB2cfCWdkFCsAAhYKHwAFDOaooeeziuafpeivoh8FBQ8va2tjeC9taGN4LmFzcHgfBgUPL2trY3gvbWhjeC5hc3B4HwdnHwlnZBQrAAIWCh8ABRLor77nqIvpgInor77lkI3ljZUfBQUPL2trY3gveGttZC5hc3B4HwYFDy9ra2N4L3hrbWQuYXNweB8HZx8JZ2QUKwACFgofAAUY5o6S6K++5pWZ5a6k5Y2g55So56S65oSPHwUFCy9jbGFzc3Jvb20vHwYFCy9jbGFzc3Jvb20vHwdnHwlnZGQCBw9kFgQCAQ9kFgRmD2QWAmYPZBYCAgEPDxYCHwAFFeivt+mAieaLqeafpeivouadoeS7tmRkAgMPZBYCAgEPZBYCAgEPEA8WAh8CZ2QQFUsM5Lqn5ZOB6K6+6K6hG+eUteawlOW3peeoi+WPiuWFtuiHquWKqOWMlgznlLXlrZDllYbliqES55S15a2Q5L+h5oGv5bel56iLLeeUteWtkOS/oeaBr+W3peeoi++8iOWNiuWvvOS9k+e7v+iJsuWFiea6kO+8iSTnlLXlrZDkv6Hmga/lt6XnqIvvvIjlhYnnlLXlt6XnqIvvvIkk55S15a2Q5L+h5oGv5bel56iL77yI5L+h5oGv5a6J5YWo77yJK+eUteWtkOS/oeaBr+W3peeoiyjogYzmlZnluIjotYQpKOS4k+WNh+acrCkh55S15a2Q5L+h5oGv5bel56iL77yI5LiT5Y2H5pys77yJBuazleWtpgznurrnu4flt6XnqIsk57q657uH5bel56iL77yI57q657uH5pyN6KOF6LS45piT77yJLee6uue7h+W3peeoi++8iOe6uue7h+WMluWtpuS4jua4hea0geeUn+S6p++8iSfnurrnu4flt6XnqIvvvIjnurrnu4fmnLrnlLXkuIDkvZPljJbvvIkq57q657uH5bel56iL77yI6Z2e57uH6YCg5p2Q5paZ5LiO5bel56iL77yJGue6uue7h+W3peeoiyjmn5PmlbTlt6XnqIspFeacjeijheiuvuiuoeS4juW3peeoizzmnI3oo4Xorr7orqHkuI7lt6XnqIvvvIjmnI3oo4XooajmvJTkuI7npL7kvJroiJ7ouYjmlZnogrLvvIkV5pyN6KOF5LiO5pyN6aWw6K6+6K6hDOW3peeoi+euoeeQhgzlt6XllYbnrqHnkIYM5bel5Lia6K6+6K6hFeWbvemZhee7j+a1juS4jui0uOaYkxrmsYnor63lm73pmYXmlZnogrIo5biI6IyDKQ/msYnor63oqIDmloflraYZ5rGJ6K+t6KiA5paH5a2mKOW4iOiMgykgIC3msYnor63oqIDmloflrabvvIjmlrDlqpLkvZPkuI7mlofljJbliJvmhI/vvIkV5YyW5a2m5bel56iL5LiO5bel6Im6DOeOr+Wig+W3peeoiwznjq/looPorr7orqEe546v5aKD6K6+6K6h77yI5Lqn5ZOB6K6+6K6h77yJG+eOr+Wig+iuvuiuoe+8iOS4k+WNh+acrO+8iQnkvJrorqHlraYb5Lya6K6h5a2m77yI5bel56iL6YCg5Lu377yJFeS8muiuoeWtpu+8iOeyvueul++8iRXkvJrorqHlrabvvIjlrqHorqHvvIkY5Lya6K6h5a2m77yI5LiT5Y2H5pys77yJDOacuuaisOW3peeoiyXmnLrmorDlt6XnqIso6IGM5pWZ5biI6LWEKSjkuJPljYfmnKwpG+acuuaisOW3peeoi++8iOS4k+WNh+acrO+8iRjorqHnrpfmnLrnp5HlrabkuI7mioDmnK8J5bu6562R5a2mIeS6pOmAmuW3peeoi++8iOmBk+i3r+S4juahpeaige+8iSrkuqTpgJrlt6XnqIvvvIjovajpgZPkuqTpgJrovabovoblt6XnqIvvvIkn5Lqk6YCa5bel56iL77yI6L2o6YGT5Lqk6YCa55S15rCU5YyW77yJKuS6pOmAmuW3peeoi++8iOi9qOmBk+S6pOmAmui/kOiQpeeuoeeQhu+8iSfkuqTpgJrlt6XnqIvvvIjovajpgZPkuqTpgJroh6rliqjljJbvvIkn5Lqk6YCa5bel56iL77yI5Lqk6YCa5o6n5Yi25LiO566h55CG77yJH+S6pOmAmuW3peeoiyjot6/moaUpKOS4k+WNh+acrCke5Lqk6YCa5bel56iL77yI54mp5rWB566h55CG77yJCemHkeiejeWtpgzml4XmuLjnrqHnkIYG5pel6K+tDOi9r+S7tuW3peeoiwzllYbliqHoi7Hor60M56S+5Lya5bel5L2cDOW4guWcuuiQpemUgBLop4bop4nkvKDovr7orr7orqEh5pWw5a2m5LiO5bqU55So5pWw5a2m77yI5biI6IyD77yJDOmAmuS/oeW3peeoiyfpgJrkv6Hlt6XnqIvvvIjorqHnrpfmnLrpgJrkv6HnvZHnu5zvvIkh6YCa5L+h5bel56iL77yI54mp6IGU572R5bel56iL77yJHumAmuS/oeW3peeoi++8iOeJqea1geeuoeeQhu+8iSrpgJrkv6Hlt6XnqIvvvIjmmbrog73liLbpgKDkv6Hmga/mioDmnK/vvIk26YCa5L+h5bel56iL77yI5LiT5Y2H5pys77yJ77yI6K6h566X5py66YCa5L+h572R57uc77yJDOWcn+acqOW3peeoiwznvZHnu5zlt6XnqIsJ6Iie6LmI5a2mG+S/oeaBr+euoeeQhuS4juS/oeaBr+ezu+e7nxXkv6Hmga/kuI7orqHnrpfnp5HlraYM6KGM5pS/566h55CGDOW6lOeUqOWMluWtphLoi7Hor63vvIjnv7vor5HvvIkS6Iux6K+t77yI5biI6IyD77yJCeiHquWKqOWMlhVLDOS6p+WTgeiuvuiuoRvnlLXmsJTlt6XnqIvlj4rlhbboh6rliqjljJYM55S15a2Q5ZWG5YqhEueUteWtkOS/oeaBr+W3peeoiy3nlLXlrZDkv6Hmga/lt6XnqIvvvIjljYrlr7zkvZPnu7/oibLlhYnmupDvvIkk55S15a2Q5L+h5oGv5bel56iL77yI5YWJ55S15bel56iL77yJJOeUteWtkOS/oeaBr+W3peeoi++8iOS/oeaBr+WuieWFqO+8iSvnlLXlrZDkv6Hmga/lt6XnqIso6IGM5pWZ5biI6LWEKSjkuJPljYfmnKwpIeeUteWtkOS/oeaBr+W3peeoi++8iOS4k+WNh+acrO+8iQbms5XlraYM57q657uH5bel56iLJOe6uue7h+W3peeoi++8iOe6uue7h+acjeijhei0uOaYk++8iS3nurrnu4flt6XnqIvvvIjnurrnu4fljJblrabkuI7muIXmtIHnlJ/kuqfvvIkn57q657uH5bel56iL77yI57q657uH5py655S15LiA5L2T5YyW77yJKue6uue7h+W3peeoi++8iOmdnue7h+mAoOadkOaWmeS4juW3peeoi++8iRrnurrnu4flt6XnqIso5p+T5pW05bel56iLKRXmnI3oo4Xorr7orqHkuI7lt6XnqIs85pyN6KOF6K6+6K6h5LiO5bel56iL77yI5pyN6KOF6KGo5ryU5LiO56S+5Lya6Iie6LmI5pWZ6IKy77yJFeacjeijheS4juacjemlsOiuvuiuoQzlt6XnqIvnrqHnkIYM5bel5ZWG566h55CGDOW3peS4muiuvuiuoRXlm73pmYXnu4/mtY7kuI7otLjmmJMa5rGJ6K+t5Zu96ZmF5pWZ6IKyKOW4iOiMgykP5rGJ6K+t6KiA5paH5a2mGeaxieivreiogOaWh+WtpijluIjojIMpICAt5rGJ6K+t6KiA5paH5a2m77yI5paw5aqS5L2T5LiO5paH5YyW5Yib5oSP77yJFeWMluWtpuW3peeoi+S4juW3peiJugznjq/looPlt6XnqIsM546v5aKD6K6+6K6hHueOr+Wig+iuvuiuoe+8iOS6p+WTgeiuvuiuoe+8iRvnjq/looPorr7orqHvvIjkuJPljYfmnKzvvIkJ5Lya6K6h5a2mG+S8muiuoeWtpu+8iOW3peeoi+mAoOS7t++8iRXkvJrorqHlrabvvIjnsr7nrpfvvIkV5Lya6K6h5a2m77yI5a6h6K6h77yJGOS8muiuoeWtpu+8iOS4k+WNh+acrO+8iQzmnLrmorDlt6XnqIsl5py65qKw5bel56iLKOiBjOaVmeW4iOi1hCko5LiT5Y2H5pysKRvmnLrmorDlt6XnqIvvvIjkuJPljYfmnKzvvIkY6K6h566X5py656eR5a2m5LiO5oqA5pyvCeW7uuetkeWtpiHkuqTpgJrlt6XnqIvvvIjpgZPot6/kuI7moaXmooHvvIkq5Lqk6YCa5bel56iL77yI6L2o6YGT5Lqk6YCa6L2m6L6G5bel56iL77yJJ+S6pOmAmuW3peeoi++8iOi9qOmBk+S6pOmAmueUteawlOWMlu+8iSrkuqTpgJrlt6XnqIvvvIjovajpgZPkuqTpgJrov5DokKXnrqHnkIbvvIkn5Lqk6YCa5bel56iL77yI6L2o6YGT5Lqk6YCa6Ieq5Yqo5YyW77yJJ+S6pOmAmuW3peeoi++8iOS6pOmAmuaOp+WItuS4jueuoeeQhu+8iR/kuqTpgJrlt6XnqIso6Lev5qGlKSjkuJPljYfmnKwpHuS6pOmAmuW3peeoi++8iOeJqea1geeuoeeQhu+8iQnph5Hono3lraYM5peF5ri4566h55CGBuaXpeivrQzova/ku7blt6XnqIsM5ZWG5Yqh6Iux6K+tDOekvuS8muW3peS9nAzluILlnLrokKXplIAS6KeG6KeJ5Lyg6L6+6K6+6K6hIeaVsOWtpuS4juW6lOeUqOaVsOWtpu+8iOW4iOiMg++8iQzpgJrkv6Hlt6XnqIsn6YCa5L+h5bel56iL77yI6K6h566X5py66YCa5L+h572R57uc77yJIemAmuS/oeW3peeoi++8iOeJqeiBlOe9keW3peeoi++8iR7pgJrkv6Hlt6XnqIvvvIjnianmtYHnrqHnkIbvvIkq6YCa5L+h5bel56iL77yI5pm66IO95Yi26YCg5L+h5oGv5oqA5pyv77yJNumAmuS/oeW3peeoi++8iOS4k+WNh+acrO+8ie+8iOiuoeeul+acuumAmuS/oee9kee7nO+8iQzlnJ/mnKjlt6XnqIsM572R57uc5bel56iLCeiInui5iOWtphvkv6Hmga/nrqHnkIbkuI7kv6Hmga/ns7vnu58V5L+h5oGv5LiO6K6h566X56eR5a2mDOihjOaUv+euoeeQhgzlupTnlKjljJblraYS6Iux6K+t77yI57+76K+R77yJEuiLseivre+8iOW4iOiMg++8iQnoh6rliqjljJYUKwNLZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZ2dnZGQCAw8WAh4HVmlzaWJsZWgWAmYPZBYCZg9kFgQCAw8UKwACZGRkAgUPFCsAAmRkZBgDBR5fX0NvbnRyb2xzUmVxdWlyZVBvc3RCYWNrS2V5X18WKAUPY3RsMDAkVHJlZVZpZXcxBR5jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJGNiWFEFHWN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkeHExBR1jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJHhxMgUdY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSR4cTMFHWN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkeHE0BR1jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJHhxNQUdY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSR4cTYFHmN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkY2JKQwUdY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSRqYzEFHWN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkamMyBR1jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJGpjMwUdY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSRqYzQFHWN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkamM1BR5jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJGNiWkMFHWN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkemMxBR1jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJHpjMgUdY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSR6YzMFHWN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkemM0BR1jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJHpjNQUdY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSR6YzYFHWN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkemM3BR1jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJHpjOAUdY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSR6YzkFHmN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkemMxMAUeY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSR6YzExBR5jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJHpjMTIFHmN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkemMxMwUeY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSR6YzE0BR5jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJHpjMTUFHmN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkemMxNgUeY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSR6YzE3BR5jdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJHpjMTgFHmN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkemMxOQUgY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSRjYlNLQkoFHmN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkY2JaWQUgY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSRjYktDREgFIGN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkY2JLQ01DBSBjdGwwMCRDb250ZW50UGxhY2VIb2xkZXIxJGNiUktMUwUgY3RsMDAkQ29udGVudFBsYWNlSG9sZGVyMSRjYlNLREQFJWN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkTGlzdFZpZXdYS0gPZ2QFJWN0bDAwJENvbnRlbnRQbGFjZUhvbGRlcjEkTGlzdFZpZXdYS1EPZ2RhRDsXShb/J3xv+ZgO33M952KB2w==',
            '__EVENTVALIDATION' => '/wEWeQL7lJ/ZCwLQ4e3vDwKslYq7DwKplYq7DwKqlYq7DwKnlYq7DwKolYq7DwKllYq7DwK+4bXwDwLGr4nUCwLDr4nUCwLEr4nUCwLBr4nUCwLCr4nUCwLO4bXwDwL2wuanDgLzwuanDgL0wuanDgLxwuanDgLywuanDgLvwuanDgLwwuanDgLtwuanDgLuwuanDgL2wqamDgL2wqqmDgL2wq6mDgL2wrKmDgL2wpamDgL2wpqmDgL2wp6mDgL2wqKmDgL2wsamDgL2wsqmDgK9g636AQL1gKTJDQLO4Y3wDwLzlvPQDwKA9cLNCgL5xcVQAuaQyrgHAuvZuB4C07OGgQ0Cua/+aAKFj8auCAKaoqWSDgLFu9S+DQKJi9biCwK/raGmBQLwj4j1DQLfiLecBgKXhM7KCQLg1ZaxDQK4guTFAgL1p4mlCAKFydvNDwKO6IbyDQKO6NKMDwKx+8ilCQLuqM+XBwKD6+/EAwKYoJuTDgK3/62BBgKSw8HTBwKL/ZZzArzx5/AFAsu87L4OAsD8mRoCyu2h1A8CzOLMswkC5NXAjwoCx4G6oAgC+s+ToQkCu+6qsggCiZiq8QoC0+Wc+gEC4viczQYCiarhlg0CrNyMSALXlo3RAQLG4b6NDQKZ4MnXCALik9fvBwKv3u/PBwLUqI+BBgL6i4bQDgKKlZTUDwK1zt/SDgLuuMrSDAKVqfC6CAL86JXjBALhwu7GDQKNhPa2BALBnt/QAQLXw8qbCgKK9pzPAgLptuHrBALbxL3iBQKE34qtBQKQsM32CAK5z6OCAQLXn/SqAwLsuIqtCgKui7riCwLw5OugCQKgivWcAwLLn5a7BwLnnaiLDAKmme8gAvnGm9wPAoe3n4ILAoyr2roIAoOMssQDAsvKytUNApDZ2bkGAsTK1tMKAsLC15wFAtyAwKEDApuMorEGAueA/JIMAoDiyWNr5+Msh4iHq9kaA+Kla76DnCgMhg==',
            'ctl00$ContentPlaceHolder1$cbRKLS' => 'on',
            'ctl00$ContentPlaceHolder1$txtRKJS' => $teacher,
            'ctl00$ContentPlaceHolder1$Button1' => '提交'
        );

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://202.192.240.54/kkcx/default.aspx');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);     //获取返回值
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($array));
        curl_setopt($ch, CURLOPT_TIMEOUT, 300);
        $result = curl_exec($ch);
        curl_close($ch);
        return $result;
    }
}