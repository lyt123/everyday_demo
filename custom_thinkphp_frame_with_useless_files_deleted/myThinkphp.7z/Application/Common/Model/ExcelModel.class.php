<?php
/* User:lyt123; Date:2016/10/27; QQ:1067081452 */
namespace Common\Model;

class ExcelModel extends CURDModel 
{
    public function read($filename)
    {
        include_once(ROOT_PATH.'Public/plugins/excel/PHPExcel/IOFactory.php');
        $objPHPExcel =  \PHPExcel_IOFactory::load($filename);
        return $objPHPExcel->getActiveSheet()->toArray(null, true, true, false);
    }
}